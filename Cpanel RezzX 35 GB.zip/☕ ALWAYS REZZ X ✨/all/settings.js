require("./module")

global.owner = "6289617554095" //nomor owner ganti aja jadi nomor asli lu
global.namabot = "RezzX" //nama bot ini
global.namaCreator = "Rezzx" //nama creator
global.autoJoin = false //NOT CHANGE / JANGAN GANTI
global.antilink = false //NOT CHANGE / JANGAN GANTI
global.versisc = '3.0.0' //NOT CHANGE / JANGAN GANTI
global.codeInvite = "CswK4kvQD1u7SfSmsYfMHZ"
global.domain = 'https://domainmu.com' //pake domain panel mu yang aktif
global.apikey = 'bagian apikey plta' //Ini bagian apikey plta kalau ga ngerti cara ambilnya chat gw 089617554095
global.capikey = 'bagian apikey pltc' //ini bagian apikey pltc kalau ga ngerti cara ambilnya chat gw 089617554095
global.eggsnya = '15' //ini id eggs kalau ga tau di biarin aja
global.location = '1' //jangan diganti nanti error loh
global.imageurl = 'https://telegra.ph/file/5499996f06bce81d47202.jpg' //ganti aja punya mu ini telegra.ph
global.isLink = 'https://chat.whatsapp.com/CSfqkrSt6NCHEctOgUrArb' //bebas mau link apaan
global.thumb = fs.readFileSync("./thumb.png") ///NOT CHANGE / JANGAN GANTI
global.audionya = fs.readFileSync("./all/sound.mp3") //NOT CHANGE / JANGAN GANTI
global.simbol = '' //Serah Lu Tapi ' jangan dihapus
global.tekspushkon = "" //NOT CHANGE / JANGAN GANTI
global.tekspushkonv2 = "" //NOT CHANGE / JANGAN GANTI
global.packname = "� Created By" //GANTI AJ
global.author = "RezzX" //GANTI SERAH MU
global.jumlah = "5" ////NOT CHANGE / JANGAN GANTI
global.dana = "" //ganti pake no lu jika ga punya kasih kosong aja
global.gopay = "" //ganti pake no lu jika ga punya kasih kosong aja
global.ovo = ""//isi pake no lu jika ga punya kasih kosong aja

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})